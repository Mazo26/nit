var statesArr = [
  {
    state: "USA",
    cId: "+1",
  },
  {
    state: "UK",
    cId: "+44",
  },
  {
    state: "Mexico",
    cId: "+52",
  },
  {
    state: "India",
    cId: "+91",
  },
  {
    state: "China",
    cId: "+86",
  },
  {
    state: "Serbia",
    cId: "+381",
  },
];
